#include <stdio.h>
#include <stdlib.h>

struct Node {
    int parsedInfo;
    struct Node* left;
    struct Node* right;
};
struct Node* insertNode(struct Node* node, int parsedInfo) {
    if (node == NULL) {
        struct Node* nn = (struct Node*)malloc(sizeof(struct Node));

        nn->parsedInfo = parsedInfo;nn->left = NULL;nn->right = NULL;
        printf("inserted\n");

        return nn;
    }
    if (parsedInfo < node->parsedInfo)
        node->left = insertNode(node->left, parsedInfo);
    else if (parsedInfo > node->parsedInfo)
        node->right = insertNode(node->right, parsedInfo);
    else {
        printf("not inserted\n");
    }
    return node;
}
struct Node* lookForNode(struct Node* node, int parsedInfo) {
    if (node == NULL) {
        printf("absent\n");return NULL;
    }
    if (node->parsedInfo == parsedInfo) {
        printf("present\n");return node;
    }
    if (parsedInfo < node->parsedInfo)
        return lookForNode(node->left, parsedInfo);
    return lookForNode(node->right, parsedInfo);
}
struct Node* LocateMin(struct Node* node) {
    struct Node* cn = node;
    while (cn->left != NULL)
        cn = cn->left;
    return cn;
}
struct Node* delNote(struct Node* root, int parsedInfo) {
    if (root == NULL) {
        printf("absent\n");
        return NULL;
    }
    if (parsedInfo < root->parsedInfo) {
        root->left = delNote(root->left, parsedInfo);
    }
    else if (parsedInfo > root->parsedInfo) {
        root->right = delNote(root->right, parsedInfo);
    }
    else {
        if (root->left == NULL) {
            struct Node* temp = root->right;
            free(root);
            printf("deleted\n");
            return temp;
        }
        else if (root->right == NULL) {
            struct Node* temp = root->left;
            free(root);
            printf("deleted\n");
            return temp;
        }
        struct Node* temp = LocateMin(root->right);
        root->parsedInfo = temp->parsedInfo;
        root->right = delNote(root->right, temp->parsedInfo);
    }
    return root;
}
void printTree(struct Node* root) {
    if (root != NULL) {
        printf("(");
        printTree(root->left);
        printf("%d", root->parsedInfo);
        printTree(root->right);
        printf(")");
    }
}
void freeMemory(struct Node* root) {
    if (root == NULL) return;
    freeMemory(root->left);
    freeMemory(root->right);
    free(root);
}

int main() {
    char input;
    struct Node* root = NULL;

    while (scanf(" %c", &input) != EOF) {
        int num;

        if (input == 'i') {
            if (scanf("%d", &num) == EOF) break;
            root = insertNode(root, num);
        }
        else if (input == 's') {
            if (scanf("%d", &num) == EOF) break;
            lookForNode(root, num);
        }
        else if (input == 'd') {
            if (scanf("%d", &num) == EOF) break;
            root = delNote(root, num);
        }
        else if (input == 'p') {
            printTree(root);
            printf("\n");
        }
    }

    freeMemory(root);
    return 0;
}
