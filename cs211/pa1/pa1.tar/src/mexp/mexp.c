#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define MAX_LINES 100
#define MAX_SIZE 100

int main(int argc, char** argv) {
    FILE* inputFile = fopen(argv[1], "r");
    int matSizeM;fscanf(inputFile, "%d", &matSizeM);
    int** array = malloc(matSizeM * sizeof(int*));int** output = malloc(matSizeM * sizeof(int*));int** temp = malloc(matSizeM * sizeof(int*));

    for(int i = 0; i < matSizeM; i++) {
        array[i] = malloc(matSizeM * sizeof(int));
        output[i] = malloc(matSizeM * sizeof(int));
        temp[i] = malloc(matSizeM * sizeof(int));
    }
    for(int i = 0; i < matSizeM; i++) {
        for(int j = 0; j < matSizeM; j++){
            fscanf(inputFile, "%d", &array[i][j]);
        }
    }
    int n;fscanf(inputFile, "%d", &n);fclose(inputFile);
    for (int i = 0; i < matSizeM; i++) {
        for (int j = 0; j < matSizeM; j++){
            output[i][j] = 0;
        }
        output[i][i] = 1;
    }

    for(int t = 0; t < n; t++){
        for(int i = 0; i < matSizeM; i++){
            for(int j = 0; j < matSizeM; j++){
                int tempSize = 0;
                for(int l = 0; l < matSizeM; l++){
                    tempSize = tempSize + output[i][l] * array[l][j];
                }
                temp[i][j] = tempSize;
            }
        }
        for(int i = 0; i < matSizeM; i++){
            for(int j = 0; j < matSizeM; j++){
                output[i][j] = temp[i][j];
            }
        }
    }
    for (int i = 0; i < matSizeM; i++) {
        for (int j = 0; j < matSizeM; j++) {
            printf("%d", output[i][j]);
            if (j < matSizeM-1) {
                printf("%s", " ");
            }
        }
        printf("\n");
    }

    for(int i = 0; i < matSizeM; i++){
        // Free internal columns and rows.
        free(array[i]);
        free(output[i]);
        free(temp[i]);
    }

    // Free memory of used matrices.
    free(array);
    free(output);
    free(temp);
}