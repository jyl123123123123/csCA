#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int compare( const void *a, const void *b) {
  return *(char*)a - *(char*)b;
}

int main(int argc, char **argv) { // O(2n) time.
    if (argc != 2) {
        printf("Invalid number of arguments.\n");
        return 1;
    }
    // printf("%s", "Sanitized Output: ");
    for (int i = 0; i < (size_t) strlen(argv[1]); i++) {
        if (isalpha(argv[1][i])) {
            argv[1][i] = tolower(argv[1][i]);
        }
    }
    qsort(argv[1],(size_t) strlen(argv[1]),(size_t) sizeof(char), compare);
    for (int i = 0; i < (size_t) strlen(argv[1]); i++) {
        if (isalpha(argv[1][i])) {
            putchar(argv[1][i]);
        }
    }
}