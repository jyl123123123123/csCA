#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAX_SIZE 100

typedef struct {
    int top;
    char stack[MAX_SIZE];
} Stack;

void initStack(Stack* stack) {
    stack->top = -1;
}

bool isEmpty(Stack* stack) {
    return (stack->top == -1);
}

bool isFull(Stack* stack) {
    return (stack->top == MAX_SIZE - 1);
}

void push(Stack* stack, char value) {
    if (isFull(stack)) {
        printf("Stack is full. Cannot push element.\n");
        return;
    }
    stack->stack[++stack->top] = value;
}

char pop(Stack* stack) {
    if (isEmpty(stack)) {
        printf("Stack is empty. Cannot pop element.\n");
        return -1;
    }
    return stack->stack[stack->top--];
}

char peek(Stack* stack) {
    if (isEmpty(stack)) {
        return -1;
    }
    return stack->stack[stack->top];
}

char matching(char c) {
    if (c == '(') return ')';
    if (c == '{') return '}';
    if (c == '[') return ']';
    if (c == '<') return '>';
    return '?';
}

int main(int argc, char **argv) {
    Stack stack;
    initStack(&stack);

    if (argc != 2) {
        printf("An invalid number of arguments were found.\n");
        return 3;
    }

    char *expr = argv[1];
    for (int i = 0; i < strlen(expr); i++) {
        char c = expr[i];
        if (c == '(' || c == '{' || c == '[' || c == '<') {
            push(&stack, c);
        }
        else if (c == ')' || c == '}' || c == ']' || c == '>') {
            if (isEmpty(&stack)) {
                printf("%d: %c", i, c);
                return 1;
            }
            char top = peek(&stack);
            if (matching(top) == c) {
                pop(&stack);
            } else {
                printf("%d%s%c", i,": ", c);
                exit(1);
            }
        }
    }

    if (!isEmpty(&stack)) {
        printf("open: ");
        while (!isEmpty(&stack)) {
            char top = pop(&stack);
            putchar(matching(top));
        }
        return 1;
    }
}
