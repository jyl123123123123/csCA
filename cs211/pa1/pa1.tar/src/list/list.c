#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

typedef struct Node {
    int value;
    struct Node* next;
} Node;

typedef struct LinkedList {
    Node* head;
} LinkedList;

int size(LinkedList* list) {
    Node* cur = list->head;
    int count = 0;
    while (cur != NULL) {
        count++;
        cur = cur->next;
    }
    return count;
}

int printList(LinkedList* list) {
    Node* cur = list->head;
    int count = 0;
    while (cur != NULL) {
        printf("%d", cur->value);
        if (cur->next != NULL) {
            printf(" ");
        }
        cur = cur->next;
        count++;
    }
    printf("\n");
    // printf("%s%d\n","The current list head is: ", list->head->value);
    return count;
}

int contains(LinkedList* list, Node* node) {
    Node* cur = list->head;
    while (cur != NULL) {
        if (cur->value == node->value) {
            return 1;
        }
        cur = cur->next;
    }
    return 0;
}

Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->value = data;
    newNode->next = NULL;
    return newNode;
}

void initLinkedList(LinkedList* list) {
    list->head = NULL;
}

void insert(LinkedList* list, int val) {
    Node* newNode = createNode(val);
    if (list->head == NULL) {
        list->head = newNode;
    } 
    else {
        if (!contains(list, newNode)) {
            Node* cur = list->head;
                if (cur->value > val) {
                    newNode->next = cur;
                    cur = newNode;
                    list->head = cur;
                    return;
                }
                while (cur->next != NULL) {
                    // printf("%s%d\n", "Looking at Node with value: ", cur->value);
                    // printf("%d%s\n", cur->next->value, " is not null.");
                    if (cur->next->value > val) {
                        // printf("%d%s%d\n", cur->value, " was more than ", val);
                        newNode->next = cur->next;
                        // printf("%s%d%s%d\n","Setting the next of Node: ",newNode->value, " to Node: ", cur->value);
                        cur->next = newNode;
                        return;
                    }
                    cur = cur->next;
                }
                cur->next = newNode;
        }
        else {
            free(newNode);
        }
    }
}

void delete(LinkedList* list, int val) {
    if (list->head == NULL) {
        return;
    } else if (list->head->value == val) {
        Node* temp = list->head;
        list->head = list->head->next;
        free(temp);
    } else {
        Node* cur = list->head;
        while (cur->next != NULL && cur->next->value != val) {
            cur = cur->next;
        }
        if (cur->next != NULL) {
            Node* temp = cur->next;
            cur->next = cur->next->next;
            free(temp);
        }
    }
}

void freeList(LinkedList* list) {
    Node* cur = list->head;
    while (cur != NULL) {
        Node* temp = cur;
        cur = cur->next;
        free(temp);
    }
    list->head = NULL;
}


int main(void) {
    LinkedList list;
    initLinkedList(&list);

    // printf("Please state your input. 'i #' for insertion, 'd #' for deletion.\n");

    char input[3];
    int num;

    while (1) {
        int result = scanf(" %2s %d", input, &num);

        if (result == EOF) {
            break;
        } else if (result != 2) {
            break;
        }

        if (input[0] == 'i') {
            insert(&list, num);
        } else if (input[0] == 'd') {
            delete(&list, num);
        } else {
            break;
        }

        printf("%d :", size(&list));
        if (size(&list) > 0) {
            printf("%s", " ");
        }
        printList(&list);
    }
    freeList(&list);
    return 0;
}
