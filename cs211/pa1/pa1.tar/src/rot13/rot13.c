#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>


int main(int argc, char **argv) {
    // printf("%s", "The original message is : ");
    for (int i = 1; i < argc; i++) {
        // printf("%s", argv[i]);
        // printf("%s"," ");
    }
    // printf("\n");

    if (argc < 2) {
        // printf("%s\n", "There is no input text.");
        return 1;
    }

    else {
        // printf("%s", "The new encoded message is : ");
        for (int i = 1; i < argc; i++) {
            for (int j = 0; j < strlen(argv[i]); j++) {
                char c = argv[i][j];
                if (isalpha(c)) {
                    if (isupper(c)) {
                        putchar((c - 'A' + 13) % 26 + 'A');
                    }
                    else {
                        putchar((c - 'a' + 13) % 26 + 'a');
                    }
                }
                else {
                    putchar(c);
                }
            }
            if (i < argc-1) {
                printf("%s"," "); // This might create issues with the auto-tester.
            }
        }
    }
    return 0;
}